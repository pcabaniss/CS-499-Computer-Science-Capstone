package com.zybooks.mainproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/***
 * Inventory Database holds all of the database functionality for the each user, and their individual inventory databases.
 */
public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    // Singleton of the database
    private static InventoryDatabase sInventoryDatabase;

    // Return current or new instance
    public static InventoryDatabase getInstance(Context context) {
        if (sInventoryDatabase == null) {
            sInventoryDatabase = new InventoryDatabase(context);
        }

        return sInventoryDatabase;
    }


    // Constructor
    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Database table for inventory items
    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_USERNAME = "username";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_QUANTITY = "quantity";
    }

    // Database table for user information
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    //-------------------------------On create/upgrade--------------------------------------------\\


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Instantiate databases
            db.execSQL("CREATE TABLE " + InventoryTable.TABLE + " (" +
                    InventoryTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    InventoryTable.COL_NAME + " TEXT, " +
                    InventoryTable.COL_DESCRIPTION + " TEXT," +
                    InventoryTable.COL_USERNAME + " TEXT, " +
                    InventoryTable.COL_QUANTITY + " INTEGER)" );

            db.execSQL("CREATE TABLE " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserTable.COL_USERNAME + " TEXT, " +
                UserTable.COL_PASSWORD + " TEXT)" );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Check for existing database
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + InventoryTable.TABLE);
        onCreate(db);

    }

    //-------------------------------Account Functions--------------------------------------------\\

    // Add a user
    public boolean addAccount(String username, String password) {
        // Check for existing user
        if (usernameExists(username)) {
            System.out.println("User Exists!");
            return false;
        }
        System.out.println("New user.");

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues val = new ContentValues();

        val.put(UserTable.COL_USERNAME, username);
        val.put(UserTable.COL_PASSWORD, password);


        long id = db.insert(UserTable.TABLE, null, val);

        return id != -1;
    }


    // Check if a user exists
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + UserTable.TABLE + " WHERE username = ? " +
                "AND password = ?";

        Cursor cursor = db.rawQuery(query, new String[]{username, password});


        return cursor.getCount() > 0;
    }

    // Check if username exists
    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + UserTable.TABLE + " WHERE username = ?";

        Cursor cursor = db.rawQuery(query, new String[]{username});

        return cursor.getCount() > 0;
    }

    //----------------------------------Item Functions--------------------------------------------\\

    // Return list if it exists
    public List<ListItem> getItemList(AuthenticatedUser user ) {
        List<ListItem> itemList = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String query = "SELECT * FROM " + InventoryTable.TABLE + " WHERE " + InventoryTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{user.getUserName()});

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                String description = cursor.getString(2);
                int quantity = cursor.getInt(4);
                itemList.add(new ListItem(id, name, description, quantity));
            } while (cursor.moveToNext());
        }
            cursor.close();

            return itemList;
    }

    // Add a new item
    public boolean addItem(String name, String description, int quantity, AuthenticatedUser user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues val = new ContentValues();
        val.put(InventoryTable.COL_NAME, name);
        val.put(InventoryTable.COL_DESCRIPTION, description);
        val.put(InventoryTable.COL_USERNAME, user.getUserName());
        val.put(InventoryTable.COL_QUANTITY, quantity);

        long id = db.insert(InventoryTable.TABLE, null, val);

        return id != -1;
    }

    // Update an existing item
    public boolean updateItem(ListItem listItem) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues val = new ContentValues();
        val.put(InventoryTable.COL_NAME, listItem.getName());
        val.put(InventoryTable.COL_DESCRIPTION, listItem.getItemDescription());
        val.put(InventoryTable.COL_QUANTITY, listItem.getQuantity());

        // Check if username indicator matches
        int update = db.update(InventoryTable.TABLE, val,
                InventoryTable.COL_ID + " = ?",
                new String[]{String.valueOf(listItem.getId())});

        return update > 0;
    }

    // Delete an item
    public boolean deleteItem(ListItem listItem) {
        SQLiteDatabase db = getWritableDatabase();

        int deleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                new String[]{String.valueOf(listItem.getId())});

        return deleted > 0;
    }


}
