//============================================================================
// Name        : Main.java
// Author      : Phillip Cabaniss
// Version     : 1.0
// Copyright   : Copyright © 2024 SNHU COCE
// Description : A file that controls the flow of the program by using the methods within the
// BinarySearchTree.java file.
//============================================================================

package org.example;

import java.time.Clock;
import java.time.Duration;
import java.util.Scanner;

/**
 * Main function to control the program and UI.
 */
public class Main {
    public static void main(String[] args) {


        // File path
        String csvPath = "eBid_Monthly_Sales.csv";

        // Scanner for reading user input
        Scanner scanner = new Scanner(System.in);

        // Instantiate binary search tree
        BinarySearchTree bst;
        bst = new BinarySearchTree();

        long startTime;
        long stopTime;
        double ticks;

        int choice = 0;

        // While loop to control the UI.
        while (choice != 9) {
            System.out.println("Menu: ");
            System.out.println("    1. Load Bids ");
            System.out.println("    2. Display All Bids");
            System.out.println("    3. Find Bid");
            System.out.println("    4. Remove Bid");
            System.out.println("    9. Exit");
            System.out.println("Enter Choice: ");
            int input = Integer.parseInt(scanner.nextLine());


            switch (input) {

                // Load the bids into the tree and display the time elapsed
                case 1:
                    startTime = System.currentTimeMillis();
                    bst.loadBids(csvPath, bst);
                    stopTime = System.currentTimeMillis();

                    ticks = ((stopTime - startTime));
                    System.out.println("Time: " + ticks + " ticks.");
                    System.out.println("Elapsed time was " + (ticks * 1.0 / 100000) + " seconds.");
                    break;

                // Display the bids in order from the ID
                case 2:
                    try{
                        bst.inOrder();
                    }
                    catch (Error e) {
                        System.out.println("Cannot display more, file is too long.");
                    }
                    break;

                // Search for bid by ID and display the details and display the time elapsed.
                case 3:
                    System.out.println("Please enter a valid Bid ID");

                    // Improvement from C++ version, now searches by input instead of hardcoded string
                    // Get user input
                    String findBid = scanner.nextLine();

                    startTime = System.currentTimeMillis();
                    Bid found = bst.Search(findBid);
                    if (found != null) {
                        bst.displayBid(found);
                    }
                    else {
                        System.out.println("There was an issue finding the bid, please try again.");
                    }
                    stopTime = System.currentTimeMillis();

                    ticks = ((stopTime - startTime));
                    System.out.println("Time: " + ticks + " ticks.");
                    System.out.println("Elapsed time was " + (ticks * 1.0 / 100000) + " seconds.");

                    break;

                // Remove a bid by searching for it by ID.
                case 4:
                    System.out.println("Please enter a valid Bid ID");

                    // Improvement from C++ version, now removes by input instead of hardcoded string
                    // Get user input
                    String bidID = scanner.nextLine();
                    Bid check = bst.Search(bidID);
                    if (check != null) {
                        bst.Remove(bidID);
                    }
                    else {
                        System.out.println("There was an issue finding the bid, please try again.");
                    }
                    break;

                // Catch wrong input
                default:
                    System.out.println("Please make sure you put in  a valid number and try again. ");


            }
        }

        System.out.println("Good bye.");

    }

}