package com.zybooks.mainproject;

// Controls authentication of user and instances
public class AuthenticationManager {

    private AuthenticatedUser user;
    private static AuthenticationManager instance;

    private AuthenticationManager() {

    }

    /**
     * Get instance of user for database
     * @return
     */
    public static AuthenticationManager getInstance() {
        if (instance == null) {
            instance = new AuthenticationManager();
        }

        return instance;
    }

    public AuthenticatedUser getUser() {
        return user;
    }

    public void setUser(AuthenticatedUser user) {
        this.user = user;
    }
}
