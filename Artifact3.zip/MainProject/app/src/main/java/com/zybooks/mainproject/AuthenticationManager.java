//============================================================================
// Name        : AuthenticationManager.java
// Author      : Phillip Cabaniss
// Version     : 1.0
// Copyright   : Copyright © 2024 SNHU COCE
// Description : Class that controls the functionality for authenticating the user and setting the instance. Also returns instance
//               through AuthenticatedUser.java to keep variables private.
//============================================================================

package com.zybooks.mainproject;

// Controls authentication of user and instances
public class AuthenticationManager {

    private AuthenticatedUser user;
    private static AuthenticationManager instance;

    private AuthenticationManager() {

    }

    /**
     * Get instance of user for database
     * @return
     */
    public static AuthenticationManager getInstance() {
        if (instance == null) {
            instance = new AuthenticationManager();
        }

        return instance;
    }

    public AuthenticatedUser getUser() {
        return user;
    }

    public void setUser(AuthenticatedUser user) {
        this.user = user;
    }
}
