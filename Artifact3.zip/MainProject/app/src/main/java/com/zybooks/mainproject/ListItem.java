//============================================================================
// Name        : ListItem.java
// Author      : Phillip Cabaniss
// Version     : 1.0
// Copyright   : Copyright © 2024 SNHU COCE
// Description : Class that controls the functionality for an inventory item. Contains getters and
//               setters for all the data within class.
//============================================================================

package com.zybooks.mainproject;

import java.io.Serializable;

// Custom list item
public class ListItem implements Serializable{
    private long itemID;
    private String itemName;
    private String itemDescription;
    private int itemQuantity;

    /**
     * Default constructor
     */
    public ListItem() {}

    /**
     * Constructor that initializes new item at 0
     * @param id
     * @param name
     */
    public ListItem(long id, String name) {
        itemID = id;
        itemName = name;
        itemQuantity = 0;
        itemDescription = " ";
    }

    /**
     * Constructor for full item creation
     * @param id
     * @param name
     * @param quantity
     */
    public ListItem(long id, String name, String description, int quantity) {
        itemID = id;
        itemName = name;
        itemDescription = description;
        itemQuantity = quantity;
    }

    /**
     * Increment the amount by 1
     */
    public void increment() {
        this.itemQuantity++;
    }

    /**
     * Decrement the amount by 1
     */
    public void decrement() {
        if (itemQuantity > 0) {
            this.itemQuantity--;
        }
    }

    // Setters
    public void setId(long id) {
        this.itemID = id;
    }

    public void setName(String name) {
        this.itemName = name;
    }

    public void setQuantity(int quantity) {
        this.itemQuantity = quantity;
    }

    public void setItemDescription(String description) { this.itemDescription = description; }

    // Getters
    public long getId() {
        return itemID;
    }

    public String getName() {
        return itemName;
    }

    public String getItemDescription() {return itemDescription; }

    public int getQuantity() {
        return itemQuantity;
    }

}
