//============================================================================
// Name        : BinarySearchTree.java
// Author      : Phillip Cabaniss
// Version     : 1.0
// Copyright   : Copyright © 2024 SNHU COCE
// Description : A file that reads and parses a csv file, and then allows you to print, search, and remove items
//               from that file.
//============================================================================

package org.example;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
/**
 * BinarySearchTree file that controls the functionality of the algorithm. Includes methods:
 * void Insert(Bid bid)
 * void Remove(String bidId)
 * Bid Search(String bidId)
 * void addNode(Node current, Bid bid)
 * void inOrder(Node node)
 * void displayBid(Bid bid)
 * void loadBids(String csvPath, BinarySearchTree bst)
 *
 */


/**
 * Node class to hold the nodes inside the binary search tree
 */
class Node {
    // Structure of tree
    Node left;
    Node right;
    Bid bid;

    // Basic constructor
    Node() {
        right = null;
        left = null;
    }

    // Instantiate a new node with a bid
    Node(Bid aBid) {

        bid = aBid;
    }
}

/**
 * Bid class to hold the bid object
 */
class Bid {

    // Variables to hold main bid information
    String bidId;
    String title;
    String fund;
    String amount;

    // Basic constructor
    Bid() {
        amount = "$0.0";
    }
}

/**
 * Binary search tree class, controlling the operations handled inside the algorithm
 */
public class BinarySearchTree {

    // Main root node
    Node root;

    // Basic constructor
    BinarySearchTree() {
        root = null;
    }

    /**
     * Insert a new bid into the tree
     * @param bid
     */
    void Insert(Bid bid) {
        // Check if root is null
        if (root == null) {
            root = new Node(bid);
        }
        else {
            this.addNode(root, bid);
        }
    }

    /**
     * Remove a bid from the tree.
     * @param bidId
     */
    void Remove(String bidId) {
        this.removeNode(root, bidId);
    }

    /**
     * Search for a bid using the ID
     * @param bidId
     * @return
     */
    Bid Search(String bidId) {
        Node current = root;

        // Check if node is null
        while (current != null) {
            // Using compareTo to compare strings. If equals it would be zero
            if (bidId.compareTo(current.bid.bidId) == 0) {
                return current.bid;
            }
            // If less, then its less
            else if(bidId.compareTo(current.bid.bidId) < 0) {
                current = current.left;
            }
            else {
                current = current.right;
            }
        }

        // If no bid is found, return null
        Bid bid = null;

        return bid;
    }

    /**
     * Add a new node to the tree
     * @param current
     * @param bid
     */
    void addNode(Node current, Bid bid) {
        // Compare the strings to see where the bid goes.
       if (current.bid.bidId.compareTo(bid.bidId) > 0) {
           if (current.left == null) {
               current.left = new Node(bid);
           }
           else {
               this.addNode(current.left, bid);
           }
       }
       else {
           if (current.right == null) {
               current.right = new Node(bid);
           }
           else {
               this.addNode(current.right, bid);
           }
       }
    }

    /**
     * Display results ordered by ID
     */
    void inOrder() {
        this.inOrder(root);
    }

    void inOrder(Node node) {
        if (node != null) {
            // Start at the left-most node
            inOrder(node.left);

            System.out.println(node.bid.bidId + ": " + node.bid.title + ": " + node.bid.amount + ": " + node.bid.fund);

            inOrder(node.right);
        }
    }

    /**
     * Display results from greatest to least according to ID
     * @param node
     */
    void postOrder(Node node) {
        if (node != null) {
            postOrder(node.left);
            postOrder(node.right);

            System.out.println(node.bid.bidId + ": " + node.bid.title + ": " + node.bid.amount + ": " + node.bid.fund);
        }
    }

    /**
     * Remove the node and adjust the tree accordingly
     * @param node
     * @param bidId
     * @return
     */
    Node removeNode(Node node, String bidId) {
        // Instantiate a holder variable
        Node temp;

        if (node == null) {
            return node;
        }

        // Comparing the strings with a compareTo to find node.
        if (bidId.compareTo(node.bid.bidId) < 0) {
            node.left = removeNode(node.left, bidId);
        }
        else if (bidId.compareTo(node.bid.bidId) > 0) {
            node.right = removeNode(node.right, bidId);
        }
        else {
            // Bid found
            // Check if left or right nodes are null and adjust tree using the temp variable
            if (node.left == null && node.right == null) {
                node = null;
            }
            else if (node.left != null && node.right == null) {
                // Temp looks unused, but it is meant to be collected by garbage collector
                temp = node;
                node = node.right;
                temp = null;
            }
            else if (node.right != null && node.left == null) {
                temp = node;
                node = node.right;
                temp = null;
            }
            else {
                // Go to the left-most node
                temp = node.right;
                while (temp.left != null) {
                    temp = temp.left;
                }
                node.bid = temp.bid;

                node.right = removeNode(node.right, node.bid.bidId);
            }
        }
        return node;
    }


    /**
     * Display the bids information
     * @param bid
     */
    void displayBid(Bid bid) {
        System.out.println(bid.bidId + ": " + bid.title + " | " + bid.amount + " | " + bid.fund);
    }

    /**
     * Load the bids in a csv file.
     * @param csvPath
     * @param bst
     */
    void loadBids(String csvPath, BinarySearchTree bst) {
        System.out.println("Loading CSV file...   " + csvPath);

        // Object to hold bids from file
        List<String[]> bids;

        // Instantiate CSV reader
        // This is a change from the CSV parser class in C++, I had to implement this and use it to parse the .csv file
        try(CSVReader reader = new CSVReader(new FileReader(csvPath))) {
            bids = reader.readAll();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (CsvException e) {
            throw new RuntimeException(e);
        }

        // Save each bid in array with specific parsed values
        for (String[] file : bids) {
            Bid bid = new Bid();
            bid.bidId = file[1];
            bid.title = file[0];
            bid.fund = file[19];
            bid.amount = file[4];

            bst.Insert(bid);
        }

        System.out.println("Loaded bids successfully.");

    }

}
