package com.zybooks.mainproject;

// Class for getting and returning user instances
public class AuthenticatedUser {

    private String userName;

    public AuthenticatedUser(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }
}
