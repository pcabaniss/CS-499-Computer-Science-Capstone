//============================================================================
// Name        : AuthenticatedUser.java
// Author      : Phillip Cabaniss
// Version     : 1.0
// Copyright   : Copyright © 2024 SNHU COCE
// Description : Class that controls current instance of user and also returns username where needed.
//============================================================================

package com.zybooks.mainproject;

public class AuthenticatedUser {

    private String userName;

    public AuthenticatedUser(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }
}
